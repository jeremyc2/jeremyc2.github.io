<?php
    header("Content-type: text/xml\n\n");
?>
<?xml version="1.0" encoding="UTF-8"?>
<studentList>
    <student>
        <name>
            <first>
            </first>
            <middle>
            </middle>
            <last>
            </last>
        </name>
        <location>
            <city>
            </city>
            <state>
            </state>
        </location>
        <college>
            <department>
                <major>
                </major>
            </department>
        </college>
    </student>
</studentList>